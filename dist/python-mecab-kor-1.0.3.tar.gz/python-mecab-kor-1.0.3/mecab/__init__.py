from .mecab import MeCabError
from .mecab import MeCab